<h1>Welcome HOME</h1>
<ul>
	<li><a href="/about/admin/admin">About</a></li>
	<li><a href="/contact/admin/admin">Contact</a></li>
	<li><a href="/dashboard/admin/admin">Dashboard</a></li>
</ul>