<?php

use App\Http\Middleware\LoginCheck;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('../middleware_ex/home');
});

Route::get('/about/{uname}/{pass}', function ($uname, $pass) {
    return view('../middleware_ex/about');
});

Route::get('/contact/{uname}/{pass}', function ($uname, $pass) {
    return view('../middleware_ex/contact');
});

Route::get('/dashboard/{uname}/{pass}', function ($uname, $pass) {
    return view('../middleware_ex/dashboard');
});


// Route::get('/voter/{age}/', function () {
//     return view('../Voter/voter');
// })->middleware(Vote::class);

// Route::get('/', function () {
//     return view('../named_route/home');
// })->name('home-page');

// Route::get('/about', function () {
//     return view('../named_route/about');
// })->name('about-page');

// Route::get('/contact', function () {
//     return view('../named_route/contact');
// })->name('contact-page');

// Route::prefix('pages')->group(function () {
//     Route::get('/', function () {
//         return view('../Route_groups/home');
//     })->name('home');

//     Route::get('/about', function () {
//         return view('../Route_groups/about');
//     })->name('about');

//     Route::get('/contact', function () {
//         return view('../Route_groups/contact');
//     })->name('contact');
// });

// Route::view('/', '../States/home');
// Route::view('/login', '../States/login');
// Route::view('/gj', '../States/gj');
// Route::view('/hp', '../States/hp');
// Route::view('/mp', '../States/mp');
// Route::view('/mh', '../States/mh');
// Route::view('/rj', '../States/rj');
// Route::view('/up', '../States/up');

// Route::get('/states', function () {
// 	echo "States";
// });

// Route::post('/gj', function () {
// 	return Redirect('../States/gj');
// });

// Route::any('/price', function () {
// 	echo "Price";
// });

// Route::match(['get', 'post'], '/search', function () {
// 	echo "Search";
// });

// Add more routes here as needed

// Route::view('/', 'home');
// Route::view('/features', 'features');
// Route::view('/pricing', 'pricing');

// Route::get(
//     '/post/{id}',
//     function ($id) {
//         return "id number is : " . $id;
//     }
// )->where('id', '[0-9]+');

// Route::get(
//     '/post/{id}/{name}',
//     function ($id, $name) {
//         return "id number is : " . $id . " " . $name;
//     }
// );
// Route::get('user/{name?}', function ($name = null) {
//     return $name;
// });